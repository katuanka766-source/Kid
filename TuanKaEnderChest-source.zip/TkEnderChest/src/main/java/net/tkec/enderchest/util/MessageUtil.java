package net.tkec.enderchest.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;

/**
 * Ho tro chuyen doi chuoi co ma mau '&' sang Component va gui message.
 */
public final class MessageUtil {

    private MessageUtil() {
    }

    public static Component color(String raw) {
        if (raw == null) {
            return Component.empty();
        }
        return LegacyComponentSerializer.legacyAmpersand().deserialize(raw);
    }

    public static void send(CommandSender sender, String raw) {
        if (raw == null || raw.isEmpty()) {
            return;
        }
        sender.sendMessage(color(raw));
    }

    public static String replace(String template, String placeholder, String value) {
        if (template == null) {
            return "";
        }
        return template.replace(placeholder, value);
    }
}
