package net.tkec.enderchest.session;

import org.bukkit.inventory.Inventory;

import java.util.UUID;

/**
 * Dai dien cho 1 phien dang mo: viewer dang xem ender chest cua owner.
 */
public class EcSession {

    private final UUID ownerUuid;
    private final UUID viewerUuid;
    private final Inventory inventory;
    private final long openedAt;

    public EcSession(UUID ownerUuid, UUID viewerUuid, Inventory inventory) {
        this.ownerUuid = ownerUuid;
        this.viewerUuid = viewerUuid;
        this.inventory = inventory;
        this.openedAt = System.currentTimeMillis();
    }

    public UUID getOwnerUuid() {
        return ownerUuid;
    }

    public UUID getViewerUuid() {
        return viewerUuid;
    }

    public Inventory getInventory() {
        return inventory;
    }

    public long getOpenedAt() {
        return openedAt;
    }
}
