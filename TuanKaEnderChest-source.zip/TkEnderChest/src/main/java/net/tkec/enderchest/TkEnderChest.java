package net.tkec.enderchest;

import net.tkec.enderchest.commands.TkEcCommand;
import net.tkec.enderchest.config.ConfigManager;
import net.tkec.enderchest.database.DatabaseManager;
import net.tkec.enderchest.discord.DiscordWebhook;
import net.tkec.enderchest.listeners.InventoryListener;
import net.tkec.enderchest.listeners.PlayerConnectionListener;
import net.tkec.enderchest.placeholder.TkEcExpansion;
import net.tkec.enderchest.session.SessionManager;
import net.tkec.enderchest.tasks.AutoSaveTask;
import net.tkec.enderchest.util.Cooldown;
import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.SQLException;

public class TkEnderChest extends JavaPlugin {

    private ConfigManager configManager;
    private DatabaseManager databaseManager;
    private SessionManager sessionManager;
    private DiscordWebhook discordWebhook;
    private Cooldown cooldown;
    private AutoSaveTask autoSaveTask;
    private TkEcExpansion placeholderExpansion;

    @Override
    public void onEnable() {
        this.configManager = new ConfigManager(this);
        this.configManager.load();

        this.sessionManager = new SessionManager();
        this.cooldown = new Cooldown();
        this.discordWebhook = new DiscordWebhook(this, configManager);
        this.databaseManager = new DatabaseManager(this, configManager);

        try {
            databaseManager.connect();
        } catch (SQLException e) {
            getLogger().severe("Khong the ket noi MySQL! Plugin se bi vo hieu hoa. Loi: " + e.getMessage());
            Bukkit.getPluginManager().disablePlugin(this);
            return;
        }

        // Don sach cac lock cu do lan chay truoc bi crash de lai
        databaseManager.releaseAllOwnLocks();

        // Dang ky lenh
        TkEcCommand command = new TkEcCommand(this, configManager, databaseManager, sessionManager, cooldown, discordWebhook);
        if (getCommand("tkec") != null) {
            getCommand("tkec").setExecutor(command);
            getCommand("tkec").setTabCompleter(command);
        }

        // Dang ky listener
        Bukkit.getPluginManager().registerEvents(
                new InventoryListener(this, configManager, databaseManager, sessionManager), this);
        Bukkit.getPluginManager().registerEvents(
                new PlayerConnectionListener(this, configManager, databaseManager, sessionManager), this);

        // PlaceholderAPI (soft-depend)
        if (Bukkit.getPluginManager().isPluginEnabled("PlaceholderAPI")) {
            this.placeholderExpansion = new TkEcExpansion(this, cooldown, configManager);
            this.placeholderExpansion.register();
            getLogger().info("Da tich hop PlaceholderAPI.");
        }

        // Auto save
        this.autoSaveTask = new AutoSaveTask(this, databaseManager, sessionManager);
        this.autoSaveTask.start(configManager.getAutosaveIntervalSeconds());

        getLogger().info("TuanKaEnderChest da khoi dong thanh cong! Server-ID: " + configManager.getServerId());
    }

    @Override
    public void onDisable() {
        if (autoSaveTask != null) {
            autoSaveTask.stop();
        }

        // Luu toan bo phien dang mo va giai phong lock truoc khi tat
        if (sessionManager != null && databaseManager != null) {
            for (var session : sessionManager.getAllSessions()) {
                try {
                    var items = session.getInventory().getContents();
                    String base64 = net.tkec.enderchest.util.ItemSerializer.itemsToBase64(items);
                    databaseManager.saveData(session.getOwnerUuid(), base64, true).join();
                } catch (Exception e) {
                    getLogger().warning("Loi khi luu phien ender chest khi tat plugin: " + e.getMessage());
                }
            }
        }

        if (databaseManager != null) {
            databaseManager.releaseAllOwnLocks().join();
            databaseManager.shutdown();
        }

        getLogger().info("TuanKaEnderChest da tat an toan.");
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public DatabaseManager getDatabaseManager() {
        return databaseManager;
    }

    public SessionManager getSessionManager() {
        return sessionManager;
    }

    public DiscordWebhook getDiscordWebhook() {
        return discordWebhook;
    }

    public Cooldown getCooldown() {
        return cooldown;
    }

    public void reload() {
        configManager.load();
        if (autoSaveTask != null) {
            autoSaveTask.stop();
            autoSaveTask.start(configManager.getAutosaveIntervalSeconds());
        }
    }
}
