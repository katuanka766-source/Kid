package net.tkec.enderchest.database;

/**
 * Ket qua doc/khoa du lieu ender chest cua 1 nguoi choi tu database.
 */
public class EnderChestRecord {

    private final String base64Data;
    private final boolean lockAcquired;
    private final String lockedBy;

    public EnderChestRecord(String base64Data, boolean lockAcquired, String lockedBy) {
        this.base64Data = base64Data;
        this.lockAcquired = lockAcquired;
        this.lockedBy = lockedBy;
    }

    public String getBase64Data() {
        return base64Data;
    }

    public boolean isLockAcquired() {
        return lockAcquired;
    }

    public String getLockedBy() {
        return lockedBy;
    }
}
