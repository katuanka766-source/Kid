package net.tkec.enderchest.listeners;

import net.tkec.enderchest.config.ConfigManager;
import net.tkec.enderchest.database.DatabaseManager;
import net.tkec.enderchest.session.EcSession;
import net.tkec.enderchest.session.SessionManager;
import net.tkec.enderchest.util.ItemSerializer;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.UUID;
import java.util.logging.Level;

/**
 * Bukkit thuong tu dong dong inventory (bao InventoryCloseEvent) khi player quit,
 * nhung listener nay la lop bao ve them: neu vi ly do nao do phien van con ton tai
 * (owner hoac viewer thoat), chu dong luu + giai phong lock de khong khoa vinh vien.
 */
public class PlayerConnectionListener implements Listener {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final DatabaseManager databaseManager;
    private final SessionManager sessionManager;

    public PlayerConnectionListener(JavaPlugin plugin, ConfigManager config,
                                     DatabaseManager databaseManager, SessionManager sessionManager) {
        this.plugin = plugin;
        this.config = config;
        this.databaseManager = databaseManager;
        this.sessionManager = sessionManager;
    }

    @EventHandler
    public void onQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        UUID uuid = player.getUniqueId();

        // Neu player nay dang la owner cua 1 phien con mo tren server nay -> dong cuong che
        EcSession session = sessionManager.getByOwner(uuid);
        if (session != null) {
            forceCloseAndSave(session);
            return;
        }

        // Neu player nay la viewer dang xem ruong nguoi khac (admin /tkec see) ma chua bi dong
        for (EcSession s : sessionManager.getAllSessions()) {
            if (s.getViewerUuid().equals(uuid)) {
                forceCloseAndSave(s);
                return;
            }
        }
    }

    private void forceCloseAndSave(EcSession session) {
        sessionManager.remove(session);
        try {
            var contents = session.getInventory().getContents();
            String base64 = ItemSerializer.itemsToBase64(contents);
            databaseManager.saveData(session.getOwnerUuid(), base64, true);
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE,
                    "Loi khi luu ender chest luc player thoat (owner=" + session.getOwnerUuid() + ")", e);
            databaseManager.releaseLockOnly(session.getOwnerUuid());
        }
    }
}
