package net.tkec.enderchest.placeholder;

import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import net.tkec.enderchest.config.ConfigManager;
import net.tkec.enderchest.util.Cooldown;
import org.bukkit.OfflinePlayer;
import org.bukkit.plugin.java.JavaPlugin;
import org.jetbrains.annotations.NotNull;

/**
 * Cung cap cac placeholder:
 * %tuankaec_cooldown%  -> so giay con lai phai doi (0 neu dung duoc)
 * %tuankaec_oncooldown% -> "yes"/"no"
 */
public class TkEcExpansion extends PlaceholderExpansion {

    private final JavaPlugin plugin;
    private final Cooldown cooldown;
    private final ConfigManager config;

    public TkEcExpansion(JavaPlugin plugin, Cooldown cooldown, ConfigManager config) {
        this.plugin = plugin;
        this.cooldown = cooldown;
        this.config = config;
    }

    @Override
    public @NotNull String getIdentifier() {
        return "tuankaec";
    }

    @Override
    public @NotNull String getAuthor() {
        return "TkTeam";
    }

    @Override
    public @NotNull String getVersion() {
        return "1.0.0";
    }

    @Override
    public boolean persist() {
        return true;
    }

    @Override
    public String onRequest(OfflinePlayer player, @NotNull String params) {
        if (player == null) {
            return "";
        }

        if (params.equalsIgnoreCase("cooldown")) {
            long remaining = cooldown.getRemainingSeconds(player.getUniqueId(), config.getCooldownSeconds());
            return String.valueOf(remaining);
        }

        if (params.equalsIgnoreCase("oncooldown")) {
            long remaining = cooldown.getRemainingSeconds(player.getUniqueId(), config.getCooldownSeconds());
            return remaining > 0 ? "yes" : "no";
        }

        return null;
    }
}
