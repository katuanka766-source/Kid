package net.tkec.enderchest.database;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import net.tkec.enderchest.config.ConfigManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;

/**
 * Quan ly ket noi MySQL (HikariCP) va toan bo logic doc/ghi/lock du lieu ender chest.
 *
 * Co che chong dupe:
 * - Moi ban ghi co locked_by (server dang giu quyen) va locked_at (thoi diem giu).
 * - Khi mo ruong: thuc hien 1 cau lenh INSERT ... ON DUPLICATE KEY UPDATE de "gianh" lock
 *   mot cach nguyen tu (atomic), chi thanh cong neu lock dang trong, thuoc ve chinh server nay,
 *   hoac lock da qua "het han" (lock-timeout-seconds) - phong truong hop server giu lock bi crash.
 * - Sau khi gianh duoc, doc lai ban ghi de xac nhan locked_by == server nay -> moi duoc mo.
 * - Khi dong ruong: luu du lieu + giai phong lock (locked_by = NULL).
 */
public class DatabaseManager {

    private static final String TABLE = "tkec_data";

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final ExecutorService executor;

    private HikariDataSource dataSource;

    public DatabaseManager(JavaPlugin plugin, ConfigManager config) {
        this.plugin = plugin;
        this.config = config;
        this.executor = Executors.newFixedThreadPool(4, r -> {
            Thread t = new Thread(r, "TuanKaEnderChest-DB");
            t.setDaemon(true);
            return t;
        });
    }

    public void connect() throws SQLException {
        HikariConfig hikariConfig = new HikariConfig();
        String jdbcUrl = "jdbc:mysql://" + config.getMysqlHost() + ":" + config.getMysqlPort()
                + "/" + config.getMysqlDatabase()
                + "?useSSL=" + config.isMysqlUseSSL()
                + "&autoReconnect=true&characterEncoding=utf8";

        hikariConfig.setJdbcUrl(jdbcUrl);
        hikariConfig.setUsername(config.getMysqlUsername());
        hikariConfig.setPassword(config.getMysqlPassword());
        hikariConfig.setMaximumPoolSize(config.getMysqlPoolSize());
        hikariConfig.setConnectionTimeout(config.getMysqlConnectionTimeoutMs());
        hikariConfig.setPoolName("TuanKaEnderChest-Pool");
        hikariConfig.addDataSourceProperty("cachePrepStmts", "true");
        hikariConfig.addDataSourceProperty("prepStmtCacheSize", "250");
        hikariConfig.addDataSourceProperty("prepStmtCacheSqlLimit", "2048");

        this.dataSource = new HikariDataSource(hikariConfig);

        try (Connection conn = dataSource.getConnection(); Statement st = conn.createStatement()) {
            st.executeUpdate("CREATE TABLE IF NOT EXISTS " + TABLE + " (" +
                    "uuid VARCHAR(36) NOT NULL PRIMARY KEY," +
                    "data LONGTEXT," +
                    "locked_by VARCHAR(64) DEFAULT NULL," +
                    "locked_at BIGINT DEFAULT NULL," +
                    "updated_at BIGINT DEFAULT NULL" +
                    ") ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");
        }
    }

    public void shutdown() {
        executor.shutdown();
        try {
            executor.awaitTermination(10, TimeUnit.SECONDS);
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        }
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
        }
    }

    /**
     * Co gang gianh lock va tra ve du lieu hien tai neu thanh cong.
     */
    public CompletableFuture<EnderChestRecord> tryAcquireLock(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            long now = System.currentTimeMillis();
            long staleBefore = now - (config.getLockTimeoutSeconds() * 1000L);
            String serverId = config.getServerId();

            String upsert = "INSERT INTO " + TABLE + " (uuid, data, locked_by, locked_at, updated_at) " +
                    "VALUES (?, '', ?, ?, ?) " +
                    "ON DUPLICATE KEY UPDATE " +
                    "locked_by = IF(locked_by IS NULL OR locked_by = ? OR locked_at < ?, ?, locked_by), " +
                    "locked_at = IF(locked_by IS NULL OR locked_by = ? OR locked_at < ?, ?, locked_at)";

            String select = "SELECT data, locked_by FROM " + TABLE + " WHERE uuid = ?";

            try (Connection conn = dataSource.getConnection()) {
                try (PreparedStatement ps = conn.prepareStatement(upsert)) {
                    ps.setString(1, uuid.toString());
                    ps.setString(2, serverId);
                    ps.setLong(3, now);
                    ps.setLong(4, now);
                    ps.setString(5, serverId);
                    ps.setLong(6, staleBefore);
                    ps.setString(7, serverId);
                    ps.setString(8, serverId);
                    ps.setLong(9, staleBefore);
                    ps.setLong(10, now);
                    ps.executeUpdate();
                }

                try (PreparedStatement ps = conn.prepareStatement(select)) {
                    ps.setString(1, uuid.toString());
                    try (ResultSet rs = ps.executeQuery()) {
                        if (rs.next()) {
                            String data = rs.getString("data");
                            String lockedBy = rs.getString("locked_by");
                            boolean acquired = serverId.equals(lockedBy);
                            return new EnderChestRecord(data, acquired, lockedBy);
                        }
                    }
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Loi khi gianh lock ender chest cho " + uuid, e);
            }
            return new EnderChestRecord(null, false, null);
        }, executor);
    }

    /**
     * Luu du lieu va (tuy chon) giai phong lock.
     */
    public CompletableFuture<Void> saveData(UUID uuid, String base64Data, boolean releaseLock) {
        return CompletableFuture.runAsync(() -> {
            String sql;
            if (releaseLock) {
                sql = "UPDATE " + TABLE + " SET data = ?, locked_by = NULL, locked_at = NULL, updated_at = ? WHERE uuid = ?";
            } else {
                sql = "UPDATE " + TABLE + " SET data = ?, updated_at = ? WHERE uuid = ?";
            }
            try (Connection conn = dataSource.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, base64Data);
                ps.setLong(2, System.currentTimeMillis());
                ps.setString(3, uuid.toString());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Loi khi luu du lieu ender chest cho " + uuid, e);
            }
        }, executor);
    }

    /**
     * Giu lock con "song" (dung trong autosave) de tranh bi coi la stale trong khi van dang mo hop le.
     */
    public CompletableFuture<Void> refreshLock(UUID uuid) {
        return CompletableFuture.runAsync(() -> {
            String sql = "UPDATE " + TABLE + " SET locked_at = ? WHERE uuid = ? AND locked_by = ?";
            try (Connection conn = dataSource.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setLong(1, System.currentTimeMillis());
                ps.setString(2, uuid.toString());
                ps.setString(3, config.getServerId());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Loi khi refresh lock cho " + uuid, e);
            }
        }, executor);
    }

    /**
     * Giai phong toan bo lock ma server nay dang giu. Goi luc onEnable (don lock cu do crash)
     * va onDisable (dong an toan).
     */
    public CompletableFuture<Void> releaseAllOwnLocks() {
        return CompletableFuture.runAsync(() -> {
            String sql = "UPDATE " + TABLE + " SET locked_by = NULL, locked_at = NULL WHERE locked_by = ?";
            try (Connection conn = dataSource.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, config.getServerId());
                int rows = ps.executeUpdate();
                if (rows > 0) {
                    plugin.getLogger().info("Da giai phong " + rows + " lock ender chest cu (tu lan chay truoc).");
                }
            } catch (SQLException e) {
                plugin.getLogger().log(Level.WARNING, "Loi khi giai phong lock cu", e);
            }
        }, executor);
    }

    /**
     * Chi giai phong lock, KHONG dong den cot data. Dung khi xay ra loi truoc khi save
     * de tranh ghi de/mat du lieu cu, nhung van phai tranh khoa vinh vien.
     */
    public CompletableFuture<Void> releaseLockOnly(UUID uuid) {
        return CompletableFuture.runAsync(() -> {
            String sql = "UPDATE " + TABLE + " SET locked_by = NULL, locked_at = NULL WHERE uuid = ? AND locked_by = ?";
            try (Connection conn = dataSource.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                ps.setString(1, uuid.toString());
                ps.setString(2, config.getServerId());
                ps.executeUpdate();
            } catch (SQLException e) {
                plugin.getLogger().log(Level.SEVERE, "Loi khi giai phong lock (khong dong data) cho " + uuid, e);
            }
        }, executor);
    }

    public ExecutorService getExecutor() {
        return executor;
    }
}
