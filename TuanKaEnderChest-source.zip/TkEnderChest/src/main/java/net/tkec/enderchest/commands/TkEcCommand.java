package net.tkec.enderchest.commands;

import net.kyori.adventure.text.Component;
import net.tkec.enderchest.config.ConfigManager;
import net.tkec.enderchest.database.DatabaseManager;
import net.tkec.enderchest.database.EnderChestRecord;
import net.tkec.enderchest.discord.DiscordWebhook;
import net.tkec.enderchest.session.EcSession;
import net.tkec.enderchest.session.SessionManager;
import net.tkec.enderchest.util.Cooldown;
import net.tkec.enderchest.util.ItemSerializer;
import net.tkec.enderchest.util.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class TkEcCommand implements CommandExecutor, TabCompleter {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final DatabaseManager databaseManager;
    private final SessionManager sessionManager;
    private final Cooldown cooldown;
    private final DiscordWebhook discordWebhook;

    public TkEcCommand(JavaPlugin plugin, ConfigManager config, DatabaseManager databaseManager,
                        SessionManager sessionManager, Cooldown cooldown, DiscordWebhook discordWebhook) {
        this.plugin = plugin;
        this.config = config;
        this.databaseManager = databaseManager;
        this.sessionManager = sessionManager;
        this.cooldown = cooldown;
        this.discordWebhook = discordWebhook;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length >= 1 && args[0].equalsIgnoreCase("reload")) {
            return handleReload(sender);
        }

        if (args.length >= 2 && args[0].equalsIgnoreCase("see")) {
            return handleSee(sender, args[1]);
        }

        return handleSelfOpen(sender);
    }

    private boolean handleReload(CommandSender sender) {
        if (!sender.hasPermission("tkec.reload")) {
            MessageUtil.send(sender, config.getMessage("no-permission"));
            return true;
        }
        config.load();
        MessageUtil.send(sender, config.getMessage("reload-success"));
        return true;
    }

    private boolean handleSelfOpen(CommandSender sender) {
        if (!(sender instanceof Player player)) {
            MessageUtil.send(sender, config.getMessage("only-player"));
            return true;
        }
        if (!player.hasPermission("tkec.use")) {
            MessageUtil.send(player, config.getMessage("no-permission"));
            return true;
        }

        if (!checkCooldown(player)) {
            return true;
        }

        openEnderChest(player, player.getUniqueId(), player.getName(), false);
        return true;
    }

    private boolean handleSee(CommandSender sender, String targetName) {
        if (!(sender instanceof Player player)) {
            MessageUtil.send(sender, config.getMessage("only-player"));
            return true;
        }
        if (!player.hasPermission("tkec.see")) {
            MessageUtil.send(player, config.getMessage("no-permission"));
            return true;
        }

        OfflinePlayer target = Bukkit.getPlayerExact(targetName);
        if (target == null) {
            target = Bukkit.getOfflinePlayer(targetName);
        }
        if (target == null || (target.getName() == null && !target.hasPlayedBefore())) {
            MessageUtil.send(player, config.getMessage("player-not-found"));
            return true;
        }

        String resolvedName = target.getName() != null ? target.getName() : targetName;

        MessageUtil.send(player, MessageUtil.replace(config.getMessage("opening-other"), "%player%", resolvedName));
        openEnderChest(player, target.getUniqueId(), resolvedName, true);
        return true;
    }

    private boolean checkCooldown(Player player) {
        if (player.hasPermission("tkec.cooldown.bypass")) {
            return true;
        }
        long remaining = cooldown.getRemainingSeconds(player.getUniqueId(), config.getCooldownSeconds());
        if (remaining > 0) {
            MessageUtil.send(player, MessageUtil.replace(config.getMessage("cooldown"), "%time%", String.valueOf(remaining)));
            return false;
        }
        return true;
    }

    /**
     * ownerUuid = chu so huu du lieu ender chest (chinh minh, hoac nguoi bi admin xem)
     * viewerUuid = nguoi thuc su dang mo GUI (= sender)
     */
    private void openEnderChest(Player viewer, UUID ownerUuid, String ownerName, boolean isAdminView) {
        if (sessionManager.isOwnerOpen(ownerUuid)) {
            MessageUtil.send(viewer, config.getMessage("already-open"));
            return;
        }

        databaseManager.tryAcquireLock(ownerUuid).thenAccept(record ->
                Bukkit.getScheduler().runTask(plugin, () -> {
                    if (!viewer.isOnline()) {
                        // Neu viewer da thoat trong luc cho DB tra ket qua, giai phong lock ngay
                        if (record.isLockAcquired()) {
                            databaseManager.releaseLockOnly(ownerUuid);
                        }
                        return;
                    }

                    handleLockResult(viewer, ownerUuid, ownerName, isAdminView, record);
                })
        ).exceptionally(ex -> {
            plugin.getLogger().severe("Loi khong xac dinh khi mo ender chest: " + ex.getMessage());
            Bukkit.getScheduler().runTask(plugin, () -> MessageUtil.send(viewer, config.getMessage("error-generic")));
            return null;
        });

        cooldown.trigger(viewer.getUniqueId());
    }

    private void handleLockResult(Player viewer, UUID ownerUuid, String ownerName, boolean isAdminView, EnderChestRecord record) {
        if (!record.isLockAcquired()) {
            MessageUtil.send(viewer, config.getMessage("locked-elsewhere"));
            if (record.getLockedBy() != null) {
                discordWebhook.sendDupeAttempt(viewer.getName(), ownerName, record.getLockedBy());
            }
            return;
        }

        // Da gianh duoc lock -> lai kiem tra local session (tranh race hiem gap khi 2 lenh gan nhau)
        if (sessionManager.isOwnerOpen(ownerUuid)) {
            MessageUtil.send(viewer, config.getMessage("already-open"));
            databaseManager.releaseLockOnly(ownerUuid);
            return;
        }

        int size = config.getEnderchestSize();
        ItemStack[] items = ItemSerializer.itemsFromBase64(record.getBase64Data(), size);

        Component title = MessageUtil.color(config.getEnderchestTitle());
        Inventory inv = Bukkit.createInventory(null, size, title);

        int copyLength = Math.min(size, items.length);
        ItemStack[] toSet = new ItemStack[size];
        System.arraycopy(items, 0, toSet, 0, copyLength);
        inv.setContents(toSet);

        EcSession session = new EcSession(ownerUuid, viewer.getUniqueId(), inv);
        sessionManager.register(session);

        viewer.openInventory(inv);

        if (isAdminView) {
            discordWebhook.sendAdminView(viewer.getName(), ownerName);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1) {
            List<String> options = new ArrayList<>();
            if (sender.hasPermission("tkec.see")) {
                options.add("see");
            }
            if (sender.hasPermission("tkec.reload")) {
                options.add("reload");
            }
            String partial = args[0].toLowerCase();
            result = options.stream().filter(o -> o.startsWith(partial)).collect(Collectors.toList());
        } else if (args.length == 2 && args[0].equalsIgnoreCase("see") && sender.hasPermission("tkec.see")) {
            String partial = args[1].toLowerCase();
            result = Bukkit.getOnlinePlayers().stream()
                    .map(Player::getName)
                    .filter(n -> n.toLowerCase().startsWith(partial))
                    .collect(Collectors.toList());
        }
        return result;
    }
}
