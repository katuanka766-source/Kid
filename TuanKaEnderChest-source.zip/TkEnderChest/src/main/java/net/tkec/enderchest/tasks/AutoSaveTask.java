package net.tkec.enderchest.tasks;

import net.tkec.enderchest.database.DatabaseManager;
import net.tkec.enderchest.session.EcSession;
import net.tkec.enderchest.session.SessionManager;
import net.tkec.enderchest.util.ItemSerializer;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

/**
 * Tu dong luu du lieu cua cac phien dang mo theo chu ky, va refresh lock
 * de tranh bi coi la "lock chet" trong khi van dang mo hop le.
 */
public class AutoSaveTask {

    private final JavaPlugin plugin;
    private final DatabaseManager databaseManager;
    private final SessionManager sessionManager;

    private BukkitTask task;

    public AutoSaveTask(JavaPlugin plugin, DatabaseManager databaseManager, SessionManager sessionManager) {
        this.plugin = plugin;
        this.databaseManager = databaseManager;
        this.sessionManager = sessionManager;
    }

    public void start(long intervalSeconds) {
        long ticks = Math.max(20L, intervalSeconds * 20L);
        this.task = plugin.getServer().getScheduler().runTaskTimer(plugin, this::runSave, ticks, ticks);
    }

    private void runSave() {
        for (EcSession session : sessionManager.getAllSessions()) {
            try {
                var contents = session.getInventory().getContents();
                String base64 = ItemSerializer.itemsToBase64(contents);
                databaseManager.saveData(session.getOwnerUuid(), base64, false)
                        .thenRun(() -> databaseManager.refreshLock(session.getOwnerUuid()));
            } catch (Exception e) {
                plugin.getLogger().log(Level.WARNING, "Loi autosave ender chest cho " + session.getOwnerUuid(), e);
            }
        }
    }

    public void stop() {
        if (task != null) {
            task.cancel();
            task = null;
        }
    }
}
