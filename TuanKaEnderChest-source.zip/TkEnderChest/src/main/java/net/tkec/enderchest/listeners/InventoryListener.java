package net.tkec.enderchest.listeners;

import net.tkec.enderchest.config.ConfigManager;
import net.tkec.enderchest.database.DatabaseManager;
import net.tkec.enderchest.session.EcSession;
import net.tkec.enderchest.session.SessionManager;
import net.tkec.enderchest.util.ItemSerializer;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

/**
 * Khi nguoi choi dong ender chest (tu server nay mo ra), luu du lieu va giai phong lock.
 */
public class InventoryListener implements Listener {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final DatabaseManager databaseManager;
    private final SessionManager sessionManager;

    public InventoryListener(JavaPlugin plugin, ConfigManager config,
                              DatabaseManager databaseManager, SessionManager sessionManager) {
        this.plugin = plugin;
        this.config = config;
        this.databaseManager = databaseManager;
        this.sessionManager = sessionManager;
    }

    @EventHandler
    public void onInventoryClose(InventoryCloseEvent event) {
        EcSession session = sessionManager.getByInventory(event.getInventory());
        if (session == null) {
            return;
        }

        // Bo dang ky ngay de cho phep mo lai tuc thi (chi khi da luu xong that ra an toan hon,
        // nhung de tranh "khoa vinh vien" neu luu bi loi, ta bo dang ky truoc va luu bat dong bo sau)
        sessionManager.remove(session);

        try {
            var contents = event.getInventory().getContents();
            String base64 = ItemSerializer.itemsToBase64(contents);
            databaseManager.saveData(session.getOwnerUuid(), base64, true)
                    .exceptionally(ex -> {
                        plugin.getLogger().log(Level.SEVERE,
                                "Loi khi luu ender chest sau khi dong ruong cua " + session.getOwnerUuid(), ex);
                        return null;
                    });
        } catch (Exception e) {
            plugin.getLogger().log(Level.SEVERE,
                    "Loi khi serialize ender chest cua " + session.getOwnerUuid(), e);
            // Chi giai phong lock, KHONG dong den du lieu cu de tranh mat item
            databaseManager.releaseLockOnly(session.getOwnerUuid());
        }
    }
}
