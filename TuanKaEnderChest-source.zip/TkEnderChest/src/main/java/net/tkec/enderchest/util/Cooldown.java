package net.tkec.enderchest.util;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Quan ly cooldown don gian theo UUID nguoi choi, luu tren RAM cua server hien tai.
 */
public final class Cooldown {

    private final Map<UUID, Long> lastUse = new ConcurrentHashMap<>();

    /**
     * @return so giay con lai phai doi (0 neu duoc phep dung ngay)
     */
    public long getRemainingSeconds(UUID uuid, long cooldownSeconds) {
        Long last = lastUse.get(uuid);
        if (last == null) {
            return 0;
        }
        long elapsedMs = System.currentTimeMillis() - last;
        long remainingMs = (cooldownSeconds * 1000L) - elapsedMs;
        if (remainingMs <= 0) {
            return 0;
        }
        return (remainingMs / 1000L) + 1;
    }

    public void trigger(UUID uuid) {
        lastUse.put(uuid, System.currentTimeMillis());
    }

    public void clear(UUID uuid) {
        lastUse.remove(uuid);
    }
}
