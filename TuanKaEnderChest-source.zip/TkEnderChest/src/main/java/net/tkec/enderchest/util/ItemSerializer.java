package net.tkec.enderchest.util;

import org.bukkit.inventory.ItemStack;
import org.bukkit.util.io.BukkitObjectInputStream;
import org.bukkit.util.io.BukkitObjectOutputStream;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Base64;

/**
 * Chuyen doi noi dung inventory (ItemStack[]) sang chuoi Base64 de luu MySQL va nguoc lai.
 */
public final class ItemSerializer {

    private ItemSerializer() {
    }

    public static String itemsToBase64(ItemStack[] items) throws IOException {
        try (ByteArrayOutputStream out = new ByteArrayOutputStream();
             BukkitObjectOutputStream dataOutput = new BukkitObjectOutputStream(out)) {

            dataOutput.writeInt(items.length);
            for (ItemStack item : items) {
                dataOutput.writeObject(item);
            }
            dataOutput.flush();
            return Base64.getEncoder().encodeToString(out.toByteArray());
        }
    }

    public static ItemStack[] itemsFromBase64(String data, int fallbackSize) {
        if (data == null || data.isEmpty()) {
            return new ItemStack[fallbackSize];
        }
        try (ByteArrayInputStream in = new ByteArrayInputStream(Base64.getDecoder().decode(data));
             BukkitObjectInputStream dataInput = new BukkitObjectInputStream(in)) {

            int size = dataInput.readInt();
            ItemStack[] items = new ItemStack[Math.max(size, fallbackSize)];
            for (int i = 0; i < size; i++) {
                Object obj = dataInput.readObject();
                items[i] = (ItemStack) obj;
            }
            return items;
        } catch (Exception e) {
            // Du lieu loi/hong -> tra ve ruong rong de khong crash, tranh mat toan bo item vinh vien
            return new ItemStack[fallbackSize];
        }
    }
}
