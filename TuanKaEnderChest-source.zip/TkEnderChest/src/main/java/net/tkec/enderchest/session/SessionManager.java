package net.tkec.enderchest.session;

import org.bukkit.inventory.Inventory;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Theo doi cac phien ender chest dang mo TREN SERVER HIEN TAI (khong phai toan cluster).
 * Dung de:
 * - Ngan 2 nguoi cung mo 1 ruong (cua cung 1 owner) tren cung server nay.
 * - Lay danh sach phien de autosave / luu khi tat plugin.
 * - Xac dinh phien tuong ung khi InventoryCloseEvent xay ra.
 */
public class SessionManager {

    // key = ownerUuid (chu so huu du lieu ender chest)
    private final Map<UUID, EcSession> sessionsByOwner = new ConcurrentHashMap<>();
    // key = Inventory instance -> ownerUuid, de tra cuu nhanh khi dong ruong
    private final Map<Inventory, UUID> ownerByInventory = new ConcurrentHashMap<>();

    public boolean isOwnerOpen(UUID ownerUuid) {
        return sessionsByOwner.containsKey(ownerUuid);
    }

    public void register(EcSession session) {
        sessionsByOwner.put(session.getOwnerUuid(), session);
        ownerByInventory.put(session.getInventory(), session.getOwnerUuid());
    }

    public EcSession getByOwner(UUID ownerUuid) {
        return sessionsByOwner.get(ownerUuid);
    }

    public EcSession getByInventory(Inventory inventory) {
        UUID owner = ownerByInventory.get(inventory);
        if (owner == null) {
            return null;
        }
        return sessionsByOwner.get(owner);
    }

    public void remove(EcSession session) {
        sessionsByOwner.remove(session.getOwnerUuid());
        ownerByInventory.remove(session.getInventory());
    }

    public Collection<EcSession> getAllSessions() {
        return sessionsByOwner.values();
    }
}
