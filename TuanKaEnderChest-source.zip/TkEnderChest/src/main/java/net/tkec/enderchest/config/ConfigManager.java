package net.tkec.enderchest.config;

import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * Doc va cache cac gia tri tu config.yml.
 */
public class ConfigManager {

    private final JavaPlugin plugin;

    private String serverId;

    private String mysqlHost;
    private int mysqlPort;
    private String mysqlDatabase;
    private String mysqlUsername;
    private String mysqlPassword;
    private boolean mysqlUseSSL;
    private int mysqlPoolSize;
    private long mysqlConnectionTimeoutMs;

    private int enderchestSize;
    private String enderchestTitle;
    private long lockTimeoutSeconds;
    private long autosaveIntervalSeconds;

    private long cooldownSeconds;

    private boolean discordEnabled;
    private String discordWebhookUrl;
    private boolean discordLogDupeAttempt;
    private boolean discordLogAdminView;

    public ConfigManager(JavaPlugin plugin) {
        this.plugin = plugin;
    }

    public void load() {
        plugin.saveDefaultConfig();
        plugin.reloadConfig();
        FileConfiguration cfg = plugin.getConfig();

        this.serverId = cfg.getString("server-id", "server-1");

        this.mysqlHost = cfg.getString("mysql.host", "localhost");
        this.mysqlPort = cfg.getInt("mysql.port", 3306);
        this.mysqlDatabase = cfg.getString("mysql.database", "tkec");
        this.mysqlUsername = cfg.getString("mysql.username", "root");
        this.mysqlPassword = cfg.getString("mysql.password", "");
        this.mysqlUseSSL = cfg.getBoolean("mysql.useSSL", false);
        this.mysqlPoolSize = cfg.getInt("mysql.pool-size", 10);
        this.mysqlConnectionTimeoutMs = cfg.getLong("mysql.connection-timeout-ms", 10000);

        this.enderchestSize = cfg.getInt("enderchest.size", 27);
        this.enderchestTitle = cfg.getString("enderchest.title", "&8Ender Chest");
        this.lockTimeoutSeconds = cfg.getLong("enderchest.lock-timeout-seconds", 15);
        this.autosaveIntervalSeconds = cfg.getLong("enderchest.autosave-interval-seconds", 300);

        this.cooldownSeconds = cfg.getLong("cooldown.seconds", 5);

        this.discordEnabled = cfg.getBoolean("discord.enabled", false);
        this.discordWebhookUrl = cfg.getString("discord.webhook-url", "");
        this.discordLogDupeAttempt = cfg.getBoolean("discord.log-dupe-attempt", true);
        this.discordLogAdminView = cfg.getBoolean("discord.log-admin-view", true);
    }

    public String getMessage(String path) {
        String prefix = plugin.getConfig().getString("messages.prefix", "");
        String msg = plugin.getConfig().getString("messages." + path, "");
        return prefix + msg;
    }

    public String getRawMessage(String path) {
        return plugin.getConfig().getString("messages." + path, "");
    }

    // Getters
    public String getServerId() {
        return serverId;
    }

    public String getMysqlHost() {
        return mysqlHost;
    }

    public int getMysqlPort() {
        return mysqlPort;
    }

    public String getMysqlDatabase() {
        return mysqlDatabase;
    }

    public String getMysqlUsername() {
        return mysqlUsername;
    }

    public String getMysqlPassword() {
        return mysqlPassword;
    }

    public boolean isMysqlUseSSL() {
        return mysqlUseSSL;
    }

    public int getMysqlPoolSize() {
        return mysqlPoolSize;
    }

    public long getMysqlConnectionTimeoutMs() {
        return mysqlConnectionTimeoutMs;
    }

    public int getEnderchestSize() {
        return enderchestSize;
    }

    public String getEnderchestTitle() {
        return enderchestTitle;
    }

    public long getLockTimeoutSeconds() {
        return lockTimeoutSeconds;
    }

    public long getAutosaveIntervalSeconds() {
        return autosaveIntervalSeconds;
    }

    public long getCooldownSeconds() {
        return cooldownSeconds;
    }

    public boolean isDiscordEnabled() {
        return discordEnabled;
    }

    public String getDiscordWebhookUrl() {
        return discordWebhookUrl;
    }

    public boolean isDiscordLogDupeAttempt() {
        return discordLogDupeAttempt;
    }

    public boolean isDiscordLogAdminView() {
        return discordLogAdminView;
    }
}
