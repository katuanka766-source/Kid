package net.tkec.enderchest.discord;

import net.tkec.enderchest.config.ConfigManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;
import java.util.logging.Level;

/**
 * Gui log don gian sang Discord thong qua Webhook (khong can them thu vien ngoai).
 */
public class DiscordWebhook {

    private final JavaPlugin plugin;
    private final ConfigManager config;
    private final HttpClient httpClient;

    public DiscordWebhook(JavaPlugin plugin, ConfigManager config) {
        this.plugin = plugin;
        this.config = config;
        this.httpClient = HttpClient.newBuilder()
                .connectTimeout(Duration.ofSeconds(8))
                .build();
    }

    public void sendDupeAttempt(String playerName, String targetOwnerName, String lockedByServer) {
        if (!config.isDiscordEnabled() || !config.isDiscordLogDupeAttempt()) {
            return;
        }
        String content = String.format(
                ":warning: **[Chong Dupe]** `%s` co gang mo ender chest cua `%s` nhung ruong dang bi khoa boi server `%s`.",
                playerName, targetOwnerName, lockedByServer);
        send(content);
    }

    public void sendAdminView(String adminName, String targetName) {
        if (!config.isDiscordEnabled() || !config.isDiscordLogAdminView()) {
            return;
        }
        String content = String.format(
                ":eyes: **[Admin]** `%s` da xem ender chest cua `%s`.",
                adminName, targetName);
        send(content);
    }

    private void send(String content) {
        String url = config.getDiscordWebhookUrl();
        if (url == null || url.isBlank()) {
            return;
        }
        String json = "{\"content\": \"" + escapeJson(content) + "\"}";

        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .timeout(Duration.ofSeconds(10))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(json))
                .build();

        httpClient.sendAsync(request, HttpResponse.BodyHandlers.discarding())
                .exceptionally(ex -> {
                    plugin.getLogger().log(Level.WARNING, "Khong the gui Discord webhook", ex);
                    return null;
                });
    }

    private String escapeJson(String input) {
        return input
                .replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "");
    }
}
