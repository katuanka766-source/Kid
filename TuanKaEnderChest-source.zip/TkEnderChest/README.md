# TuanKaEnderChest

Plugin Ender Chest cho Paper 1.21.4 (Java 21) — giống co che cua DonutSMP:
lenh mo o dau cung duoc, dong bo MySQL nhieu server, chong dupe, cooldown,
auto save, Discord Webhook, PlaceholderAPI.

## Build

Can may co internet + Maven (khong build duoc trong sandbox nay vi khong co mang):

```bash
cd TkEnderChest
mvn clean package
```

File jar ket qua: `target/TuanKaEnderchest.jar`

## Cai dat

1. Bo `TuanKaEnderchest.jar` vao thu muc `plugins/` cua server Paper 1.21.4.
2. Khoi dong server 1 lan de plugin tao file `config.yml`.
3. Mo `plugins/TuanKaEnderChest/config.yml`, sua:
   - `server-id`: **PHAI khac nhau** o moi server (vi du: `lobby`, `survival`, `skyblock`)
   - Thong tin `mysql` (host, port, database, username, password)
   - `discord.webhook-url` neu muon log Discord
4. Tao database MySQL trong (plugin tu tao bang `tkec_data` khi khoi dong).
5. Restart/reload server.

## Lenh & quyen

| Lenh | Quyen | Mo ta |
|---|---|---|
| `/tkec` | `tkec.use` (default: true) | Mo ender chest cua chinh minh |
| `/tkec see <player>` | `tkec.see` (default: op) | Xem/mo ender chest nguoi khac |
| `/tkec reload` | `tkec.reload` (default: op) | Reload config |
| — | `tkec.cooldown.bypass` (default: op) | Bo qua cooldown |

## Co che chong dupe (quan trong, nen hieu ro)

- Moi ender chest luu 1 dong trong bang `tkec_data` voi cot `locked_by` (ten server dang giu)
  va `locked_at` (thoi diem giu).
- Khi mo ruong, plugin thuc hien 1 cau lenh SQL **nguyen tu** (atomic) de "gianh" lock:
  chi thanh cong neu lock dang trong, thuoc chinh server nay, hoac da qua han
  `enderchest.lock-timeout-seconds` (phong server giu lock bi crash/tat dot ngot).
- Neu lock dang bi giu boi server khac va con "song" -> nguoi choi bi tu choi mo,
  tranh 2 server cung sua 1 du lieu (nguyen nhan gay dupe item).
- Khi dong ruong: luu du lieu + giai phong lock ngay.
- `AutoSaveTask` luu dinh ky (mac dinh 5 phut) cac phien dang mo lau va "refresh" lock
  de khong bi coi la lock chet trong khi van dang mo hop le.
- Khi server khoi dong (`onEnable`), plugin tu giai phong toan bo lock ma **chinh no**
  dang giu tu lan chay truoc (vi neu server vua restart, moi lock cu do no giu chac chan
  la "mo cu" con sot lai do tat khong dung cach).

## Luu y ve `lock-timeout-seconds`

Gia tri nay nen **lon hon** chu ky autosave 1 chut (mac dinh autosave 300s, timeout 15s —
ban nen chinh `lock-timeout-seconds` >= `autosave-interval-seconds` + vai chuc giay,
hoac giam autosave xuong ~10-20s, de tranh truong hop lock tu bi coi la "chet" ngay khi
nguoi choi con dang mo ruong lau tren 1 server). Vi du an toan:

```yaml
enderchest:
  lock-timeout-seconds: 30
  autosave-interval-seconds: 20
```

## Cau truc du lieu (MySQL)

```sql
CREATE TABLE tkec_data (
  uuid VARCHAR(36) NOT NULL PRIMARY KEY,
  data LONGTEXT,
  locked_by VARCHAR(64) DEFAULT NULL,
  locked_at BIGINT DEFAULT NULL,
  updated_at BIGINT DEFAULT NULL
);
```

`data` la noi dung ruong da serialize (Base64) bang `BukkitObjectOutputStream`,
nen chi doc/ghi duoc bang chinh plugin nay (hoac plugin khac cung logic serialize).

## PlaceholderAPI

- `%tuankaec_cooldown%` — so giay con lai phai doi
- `%tuankaec_oncooldown%` — `yes` / `no`

## Chua lam / co the mo rong them

- GUI rieng cho lenh `/tkec see` de phan biet ro voi ruong cua chinh minh (hien tai dung
  chung 1 loai Inventory, chi khac tieu de mac dinh — ban co the sua `title` trong code
  `TkEcCommand#handleLockResult` de hien ten owner).
- Lich su/log ai da mo ruong ai (co the them bang `tkec_logs`).
- Gioi han kich thuoc ruong theo rank/permission (hien tai 1 size chung cho tat ca).
